package com.honny.two;

public interface IMagicSquareBuilder {

	 MagicSquare build() ;

	 void make() ;

	 int[][] getMegic();
	 void init();

}
