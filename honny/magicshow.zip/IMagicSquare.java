package kr.re.kitri.play;

public interface IMagicSquare {
	void print();
	void make();
}
