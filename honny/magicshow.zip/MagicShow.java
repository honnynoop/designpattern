package kr.re.kitri.play;

public class MagicShow {

	public static void magicPrint(
			IMagicSquare magic){
		magic.make();
		magic.print();
	}
}
