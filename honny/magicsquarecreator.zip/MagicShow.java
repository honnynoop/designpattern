package com.honny.absfac;

public class MagicShow {

	public static void magicPrint(
			MagicSquare magic){
		magic.make();
		magic.print();
	}
}
